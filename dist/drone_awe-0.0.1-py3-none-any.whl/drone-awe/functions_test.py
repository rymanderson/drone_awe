import functions as fun

# test `getParams` function
print("Testing: `getParams(class, list, file, delimiter)`")
fun.getParams('Drone','paramlist.param','dji-Mavic2.param',' ')

print("\nSUCCESS: `functions.py`")
