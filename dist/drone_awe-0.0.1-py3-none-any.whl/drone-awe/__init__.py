'''
Hello, drone world!
'''