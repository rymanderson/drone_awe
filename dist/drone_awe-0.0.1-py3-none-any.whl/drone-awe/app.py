import classes
m = classes.awe({'plot':False})
m.simulate()
