{
'speedmax': 1.0,
'altitudemax': 1.0,
'endurancemax': 60.0,
'endurancemaxhover': 60.0,
'chargerpowerrating': 1.0,
'batterycapacity': 3.6,
'batteryvoltage': 1.0,
'batteryenergy': 3600.0,
'batterymass': 1.0,
'batteryrechargetime': 60.0,
'windspeedmax': 1.0,
'rotordiameter': 1.0
}